const crypto = require("crypto")
const yts = require("yt-search")
const { Client } = require('ssh2');
const { ytmp3, ytmp4 } = require("ruhend-scraper")

const seller = JSON.parse(fs.readFileSync("./data/reseller.json"))
const ownplus = JSON.parse(fs.readFileSync("./data/owner.json"))
const list = JSON.parse(fs.readFileSync("./data/list.json"))

module.exports = async (VarShade, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
	
const budy = (typeof m.text == 'string' ? m.text : '') 
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await VarShade.decodeJid(VarShade.user.id)
const isOwner = m.sender.split("@")[0] == global.owner ? true : m.fromMe ? true : ownplus.includes(m.sender)
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const isBot = botNumber.includes(m.sender)
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson, resize, sleep } = require('./system/function.js')

m.isGroup = m.chat.endsWith("g.us")
m.metadata = m.isGroup ? (await VarShade.groupMetadata(m.chat).catch(_ => {}) || {}) : {}
m.isAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == m.sender) || false) : false
m.isBotAdmin = m.metadata && m.metadata.participants ? (m.metadata.participants.find(e => e.admin !== null && e.id == botNumber) || false) : false


// >~~~~~~~~~ Database ~~~~~~~~~~~< //

if (m.isGroup) {
const chat = db.groups[m.chat]
if (chat) {
if (!("antilink" in chat)) chat.antilink = false
if (!("antilink2" in chat)) chat.antilink2 = false
} else {
db.groups[m.chat] = {
antilink: false, 
antilink2: false
}
}}

if (!isCmd) {
let check = list.find(e => e.cmd == budy.toLowerCase())
if (check) {
await m.reply(check.respon)
}}

// >~~~~~~~~ Database User ~~~~~~~~< //

const isReseller = seller.includes(m.sender) ? true : isOwner

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const fch = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {
newsletterAdminInviteMessage: {newsletterJid: `0@newsletter`, newsletterName: `Hore`, jpegThumbnail: "", caption: `Powered By VarShade—`, inviteExpiration: 0 }}}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Powered By ${namabot}`}}}

const qcmd = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `WhatsApp Bot By ${namaowner}`, "description": null, "currencyCode": "IDR", "priceAmount1000": "99999999999999999", "retailerId": `P`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

const example = async (teks) => {
const commander = ` *Contoh Penggunaan :*\n*${cmd}* ${teks}`
return m.reply(commander)
}

const capital = (string) => {
return string.charAt(0).toUpperCase() + string.slice(1);
}

if (isCmd) {
console.log(chalk.white.bgCyan.bold(namabot), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`DARI`), chalk.blue.bold(`${m.sender.split("@")[0]}`), chalk.blue.bold(`Text :`), chalk.blue.bold(`${cmd}`))
}
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(budy) && !isOwner && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await VarShade.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await VarShade.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

\`\`\`@${m.sender.split("@")[0]} Maaf pesan kamu saya akan saya hapus, karena admin atau ownerbot telah menyalakan fitur antilink grup lain!\`\`\``, mentions: [m.sender]}, {quoted: m})
await VarShade.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await VarShade.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(budy) && !isOwner && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await VarShade.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await VarShade.sendMessage(m.chat, {text: `*乂 Link Grup Terdeteksi*

\`\`\`@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin atau ownerbot telah menyalakan fitur antilink grup lain!\`\`\``, mentions: [m.sender]}, {quoted: m})
await VarShade.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
//await VarShade.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}

const whitelistid = JSON.parse(fs.readFileSync("./data/whitelistid.json"));

// >~~~~~~~~~ Command ~~~~~~~~~~< //

switch (command) {
case "menu":
case "help": {
let anjay = `
🌟 sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ꒰ VarCpanel ꒱ 👋

> VarCpanel ᴀᴅᴀʟᴀʜ ʙᴏᴛ 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 serbaguna yang ᴅɪʀᴀɴᴄᴀɴɢ ᴜɴᴛᴜᴋ ᴍᴇɴᴅᴜᴋᴜɴɢ ᴀᴋᴛɪғɪᴛᴀs ᴠɪʀᴛᴜᴀʟ ᴋᴀᴍᴜ. ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ ᴜɴᴛᴜᴋ:  
- 📥 ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴇᴅɪᴀ
- 💰 ᴛʀᴀɴsᴀᴋsɪ ᴘᴇɴᴊᴜᴀʟᴀɴ  
- 🌐 ᴅᴀɴ ʟᴀɪɴɴʏᴀ!

ғɪᴛᴜʀ-ғɪᴛᴜʀ ᴛᴇʀsᴜsᴜɴ ʀᴀᴘɪ ᴅᴀʟᴀᴍ ᴍᴇɴᴜ ʏᴀɴɢ ᴍᴜᴅᴀʜ ᴅɪᴀᴋsᴇs~

> 🛠️ VarCpanel sᴇᴅᴀɴɢ ᴅᴀʟᴀᴍ ᴘᴇɴɢᴇᴍʙᴀɴɢᴀɴ~  
ᴍᴏʜᴏɴ ᴘᴇɴɢᴇʀᴛɪᴀɴ ᴊɪᴋᴀ ᴀᴅᴀ ʙᴜɢ ᴀᴛᴀᴜ ᴋᴇsᴀʟᴀʜᴀɴ 🙏  
ᴛᴇʀɪᴍᴀ ᴋᴀsɪʜ ᴀᴛᴀs ᴅᴜᴋᴜɴɢᴀɴɴʏᴀ! ❤️

\`🔧 ᴋᴀʟᴀᴜ ᴋᴀᴍᴜ ᴍᴇɴᴇᴍᴜᴋᴀɴ ʙᴜɢ, sɪʟᴀᴋᴀɴ ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ʏᴀ!\`


> *VarShade WhatsApp Bot*
> ────────────────────
> > Halo, @${m.sender.split("@")[0]}
> > Selamat ${ucapan()}
> > Saya VarShade Bot, siap membantu Anda.
> ────────────────────
> *Bot Info*
> > Mode: ${VarShade.public ? "Public" : "Self"}
> > Owner: @${global.namaowner}
> > Uptime: ${runtime(process.uptime())}
> ────────────────────
> *Panel Menu*
> .1gb username,628××××
> .2gb username,628××××
> .3gb username,628××××
> .4gb username,628××××
> .5gb username,628××××
> .6gb username,628××××
> .7gb username,628××××
> .8gb username,628××××
> .9gb username,628××××
> .10gb username,628××××
> .unli username,628××××
> .adp [username]
> .listpanel
> .delpanel
> ────────────────────
> *Store Menu*
> > .done
> > .dana
> > .gopay
> > .ovo
> > .qris
> ────────────────────
> *Tools*
> > .tourl
> > .sticker
> > .qc
> > .opengc
> > .closegc
> ────────────────────
> *Owner Menu*
> > .addseller
> > .delseller
> > .listseller
> > .addwl
> > .delwl
> > .listwl
> > .autodeladmin
> > .addowner
> > .delowner
> > .listowner
> > .self
> > .public
> ────────────────────
> *Gunakan dengan bijak.*
`;

let buttons = [
  {
    buttonId: ".menu",
    buttonText: { displayText: "📜 ᴍᴇɴᴜ" }
  },
  {
    buttonId: ".owner",
    buttonText: { displayText: "👑 ᴏᴡɴᴇʀ" }
  }
];

let buttonMessage = {
  document: {
    url: `https://files.catbox.moe/si1g2b.jpg`
  },
  mimetype: "image/png",
  fileName: `${ucapan()}`,
  fileLength: 69420,
  pageCount: 404,
  jpegThumbnail: fs.readFileSync('./media/vars.jpg'),
  caption: anjay,
  footer: `😎 Bot punya: ${global.namaowner}`,
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    externalAdReply: {
      title: 'VarCpane',
      body: "💬 Powered by VarShade",
      thumbnail: fs.readFileSync('./media/VarShade.jpg'),
      mediaType: 1,
      renderLargerThumbnail: true,
      previewType: 0,
      mediaUrl: '',
      sourceUrl: ''
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.idsaluran,
      newsletterName: "VarShade - Share Code!"
    }
  },
  buttons: buttons,
  viewOnce: true,
  headerType: 8
};

const flowActions = [{
  buttonId: "action",
  buttonText: {
    displayText: "Lihat Selngkapnya"
  },
  type: 4,
  nativeFlowInfo: {
    name: "single_select",
    paramsJson: JSON.stringify({
      title: "📦 Pilih Menu Sesuai Mood~",
      sections: [
        {
          title: `🔥 Paling sering dipakai`,
          highlight_label: `⚡ POPULER`,
          rows: [
            {
              header: "🌐 Menu Cpanel",
              title: "📡 List Menu Cpanel",
              id: `.cpanelmenu`
            }
          ]
        }
      ]
    })
  },
  viewOnce: true
}];

buttonMessage.buttons.push(...flowActions);

await VarShade.sendMessage(m.chat, buttonMessage, {
  quoted: fch
});
}
break
  
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case 'cpanelmenu':
case 'memucpanel': {
let kontol = ` 
> *VarShade WhatsApp Bot*
> ────────────────────
> > Halo, @${m.sender.split("@")[0]}
> > Selamat ${ucapan()}
> > Saya VarShade Bot, siap membantu Anda.
> ────────────────────
> *Bot Info*
> > Mode: ${VarShade.public ? "Public" : "Self"}
> > Owner: @${global.namaowner}
> > Uptime: ${runtime(process.uptime())}
> ────────────────────
> *Panel Menu*
> .1gb username,628××××
> .2gb username,628××××
> .3gb username,628××××
> .4gb username,628××××
> .5gb username,628××××
> .6gb username,628××××
> .7gb username,628××××
> .8gb username,628××××
> .9gb username,628××××
> .10gb username,628××××
> .unli username,628××××
> .adp [username]
> .listpanel
> .delpanel
`;
let buttons = [
  {
    buttonId: ".menu",
    buttonText: { displayText: "📜 ᴍᴇɴᴜ" }
  },
  {
    buttonId: ".owner",
    buttonText: { displayText: "👑 ᴏᴡɴᴇʀ" }
  }
];

let buttonMessage = {
  document: {
    url: `https://files.catbox.moe/si1g2b.jpg`
  },
  mimetype: "image/png",
  fileName: `${ucapan()}`,
  fileLength: 69420,
  pageCount: 404,
  jpegThumbnail: fs.readFileSync('./media/vars.jpg'),
  caption: kontol,
  footer: `😎 Bot punya: ${global.namaowner}`,
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    externalAdReply: {
      title: 'VarCpane',
      body: "💬 Powered by VarShade",
      thumbnail: fs.readFileSync('./media/VarShade.jpg'),
      mediaType: 1,
      renderLargerThumbnail: true,
      previewType: 0,
      mediaUrl: '',
      sourceUrl: ''
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.idsaluran,
      newsletterName: "VarShade - Share Code!"
    }
  },
  buttons: buttons,
  viewOnce: true,
  headerType: 8
};

const flowActions = [{
  buttonId: "action",
  buttonText: {
    displayText: "Lihat Selngkapnya"
  },
  type: 4,
  nativeFlowInfo: {
    name: "single_select",
    paramsJson: JSON.stringify({
      title: "📦 Pilih Menu Sesuai Mood~",
      sections: [
        {
          title: `🔥 Paling sering dipakai`,
          highlight_label: `⚡ POPULER`,
          rows: [
            {
              header: "🌐 Menu Cpanel",
              title: "📡 List Menu Cpanel",
              id: `.cpanelmenu`
            }
          ]
        }
      ]
    })
  },
  viewOnce: true
}];

buttonMessage.buttons.push(...flowActions);

await VarShade.sendMessage(m.chat, buttonMessage, {
  quoted: fch
});
}
break

case 'owner': {
  const kontakUtama = {
    displayName: 'VarShade',
    vcard: `BEGIN:VCARD
VERSION:3.0
N:;;;; 
FN:${global.ownername}
item1.TEL;waid=${owner}:${owner}
item1.X-ABLabel:Developer
item2.TEL;waid=${global.owner}:${global.oowner}
item2.X-ABLabel:My Owner
EMAIL;type=INTERNET:${email}
ORG:Owner VarShade
END:VCARD`
  }
  await VarShade.sendMessage(from, {
    contacts: { contacts: [kontakUtama] },
    contextInfo: {
      forwardingScore: 999,
      isForwarded: false,
      mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: true,
        renderLargerThumbnail: true,
        title: font(`VarShade - CPanel`),
        containsAutoReply: true,
        mediaType: 1,
        jpegThumbnail: fs.readFileSync('./media/VarShade.jpg'),
        mediaUrl: '',
        sourceUrl:''
      }
    }
  }, { quoted: fch })
}
break

case "addseller": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (seller.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai reseller panel!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai reseller panel!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai reseller panel!`)
await seller.push(input)
await fs.writeFileSync("./data/reseller.json", JSON.stringify(seller, null, 2))
return m.reply(`Sukses menjadikan ${input.split("@")[0]} sebagai *reseller panel*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "idgc": {
if (!m.isGroup) return m.reply(msg.group)
return m.reply(m.chat)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delseller": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (!seller.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai reseller panel!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai reseller panel!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai reseller panel!`)
const posi = seller.indexOf(input)
await seller.splice(posi, 1)
await fs.writeFileSync("./data/reseller.json", JSON.stringify(seller, null, 2))
return m.reply(`Sukses menghapus ${input.split("@")[0]} sebagai *reseller panel*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listseller": {
if (seller.length < 1) return m.reply("Tidak ada reseller panel!")
var teks = "\n *乂 List Reseller Panel Pterodactyl*\n"
for (let i of seller) {
teks += `\n * @${i.split("@")[0]}\n`
}
await VarShade.sendMessage(m.chat, {text: teks, mentions: seller}, {quoted: qchannel})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "addown": case "addowner": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (ownplus.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
await ownplus.push(input)
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply(`Sukses menjadikan ${input.split("@")[0]} sebagai *owner*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delown": case "delowner": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (!ownplus.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
const posi = ownplus.indexOf(input)
await ownplus.splice(posi, 1)
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply(`Sukses menghapus ${input.split("@")[0]} sebagai *owner*`)
}
break

case "addwl": {
    if (!isOwner) return m.reply("❌ Hanya owner yang bisa menambahkan whitelist ID!")
    if (!text || isNaN(text)) return example("Contoh: .addwl 12")

    let id = parseInt(text)
    if (whitelistid.includes(id)) return m.reply(`ID ${id} sudah ada di whitelist.`)

    whitelistid.push(id)
    fs.writeFileSync("./data/whitelistid.json", JSON.stringify(whitelistid, null, 2))
    m.reply(`✅ ID ${id} berhasil ditambahkan ke whitelist.`)
}
break

case "delwl": {
    if (!isOwner) return m.reply("❌ Hanya owner yang bisa menghapus whitelist ID!")
    if (!text || isNaN(text)) return example("Contoh: .delwl 12")

    let id = parseInt(text)
    if (!whitelistid.includes(id)) return m.reply(`ID ${id} tidak ditemukan di whitelist.`)

    whitelistid.splice(whitelistid.indexOf(id), 1)
    fs.writeFileSync("./data/whitelistid.json", JSON.stringify(whitelistid, null, 2))
    m.reply(`✅ ID ${id} berhasil dihapus dari whitelist.`)
}
break

case "listwl": {
    if (!isOwner) return m.reply("❌ Hanya owner yang bisa melihat whitelist.");

    if (whitelistid.length === 0) return m.reply("📭 Whitelist masih kosong.");

    let getUsers = await fetch(domain + "/api/application/users", {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });

    let result = await getUsers.json();
    let users = result.data;

    let list = whitelistid.map((id, i) => {
        let user = users.find(u => u.attributes.id === id);
        let username = user ? user.attributes.username : "Tidak ditemukan";
        return `• ${i + 1}. ID: ${id} | Username: ${username}`;
    }).join("\n");

    m.reply(`📋 Daftar Whitelist ID Admin Panel:\n\n${list}`);
}
break;

case "autodeladmin": {
    if (!isOwner) return m.reply("❌ Hanya owner yang bisa menjalankan perintah ini.");

    let getUsers = await fetch(domain + "/api/application/users", {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });

    let userResult = await getUsers.json();
    let users = userResult.data;
    let deleted = 0;

    for (let u of users) {
        let id = u.attributes.id;
        let isRoot = u.attributes.root_admin;

        if (isRoot && !whitelistid.includes(id)) {
            // Ambil semua server milik user
            let serverRes = await fetch(`${domain}/api/application/users/${id}/servers`, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                }
            });

            let serverData = await serverRes.json();
            if (serverData.data && serverData.data.length > 0) {
                for (let srv of serverData.data) {
                    let sid = srv.attributes.id;
                    await fetch(`${domain}/api/application/servers/${sid}`, {
                        method: "DELETE",
                        headers: {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + apikey
                        }
                    });
                    await sleep(1500); // Delay agar tidak overload API
                }
            }

            // Hapus akun admin
            await fetch(`${domain}/api/application/users/${id}`, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                }
            });
            deleted++;
            await sleep(1500);
        }
    }

    return m.reply(`✅ Autodelete selesai. Admin panel yang tidak di whitelist dan berhasil dihapus: ${deleted}`);
}
break;
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "jpm": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("teksnya & foto (opsional)")
let rest
if (/image/.test(mime)) {
rest = await VarShade.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await VarShade.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const jid = m.chat
await m.reply(`Memproses ${rest !== undefined ? "jpm teks & foto" : "jpm teks"} ke ${res.length} grup chat`)
try {
await VarShade.sendMessage(global.idsaluran, pesancoy)
} catch {}

for (let i of res) {
try {
await VarShade.sendMessage(i, pesancoy, {quoted: qchannel})
count += 1
} catch {}
await sleep(4000)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await VarShade.sendMessage(jid, {text: `Jpm ${rest !== undefined ? "teks & foto" : "teks"} berhasil dikirim ke ${count} grup`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listgc": case "listgrup": {
if (!isOwner) return
let teks = ` *── List all group chat*\n`
let a = await VarShade.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "done": case "proses": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linksaluran}`
await VarShade.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `${command == "done" ? "Transaksi Done ✅" : "Dana Masuk ✅"}`, 
body: `© Powered By ${namaowner}`, 
thumbnailUrl: global.image, 
sourceUrl: linksaluran,
}}}, {quoted: null})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "panel": {
m.reply(`
*List Panel Run Bot Private*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_
`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "dana": {
let tekspay = `
*Dana :* ${global.dana}
`
return VarShade.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ovo": {
let tekspay = `
*Ovo :* ${global.ovo}
`
return VarShade.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "gopay": {
let tekspay = `
*Gopay :* ${global.gopay}
`
return VarShade.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "qris": {
return VarShade.sendMessage(m.chat, {image: {url: global.qris}}, {quoted: qtext})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listown": case "listowner": {
if (ownplus.length < 1) return m.reply("Tidak ada owner tambahan!")
var teks = "\n *乂 List All Owner Bot*\n"
teks += `\n @${global.owner}\n`
for (let i of ownplus) {
teks += `\n * @${i.split("@")[0]}\n`
}
await VarShade.sendMessage(m.chat, {text: teks, mentions: ownplus}, {quoted: qchannel})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tourl": {
if (!/image/.test(mime)) return example("dengan kirim/reply foto")
let media = await VarShade.downloadAndSaveMediaMessage(qmsg)
//m.reply("🚀 Memproses uploading image . . ")
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'imgtmp.png')
let teks = directLink.toString()
await VarShade.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "qc": {
if (!text) return example('teksnya')
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
let ppuser
try {
ppuser = await VarShade.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/c6fbacafe23d6ab6a801e.jpg'
}
let reswarna = await warna[Math.floor(Math.random()*warna.length)]
m.reply(msg.wait)
const obj = {
      "type": "quote",
      "format": "png",
      "backgroundColor": reswarna,
      "width": 512,
      "height": 768,
      "scale": 2,
      "messages": [{
         "entities": [],
         "avatar": true,
         "from": {
            "id": 1,
            "name": m.pushName,
            "photo": {
               "url": ppuser
            }
         },
         "text": text,
         "replyMessage": {}
      }]
   }
   try {
   const json = await axios.post('https://bot.lyo.su/quote/generate', obj, {
      headers: {
         'Content-Type': 'application/json'
      }
   })
   const buffer = Buffer.from(json.data.result.image, 'base64')
VarShade.sendStimg(m.chat, buffer, m, { packname: global.packname })
   } catch (error) {
   m.reply(error.toString())
   }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await VarShade.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await VarShade.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "kick": case "kik": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (text || m.quoted) {
const input = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await VarShade.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await VarShade.groupParticipantsUpdate(m.chat, [input], 'remove')
} else {
return example("@tag/reply")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ht": case "hidetag": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!text) return example("pesannya")
let member = m.metadata.participants.map(v => v.id)
await VarShade.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return example("dengan mengirim foto/vidio")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
m.reply(msg.wait)
var media = await VarShade.downloadAndSaveMediaMessage(qmsg)
await VarShade.sendStimg(m.chat, media, m, {packname: "Whatsapp Bot 2025"})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "stickerwm": case "swn": case "wm": {
if (!text) return example("namamu & mengirim foto/vidio")
if (!/image|video/.test(mime)) return example("namamu & mengirim foto/vidio")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
m.reply(msg.wait)
var media = await VarShade.downloadAndSaveMediaMessage(qmsg)
await VarShade.sendStimg(m.chat, media, m, {packname: text})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "public": {
if (!isOwner) return m.reply(msg.owner)
VarShade.public = true
m.reply("Berhasil mengganti mode bot menjadi *Public*")
}
break

case "self": {
if (!isOwner) return m.reply(msg.owner)
VarShade.public = false
m.reply("Berhasil mengganti mode bot menjadi *Self*")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb":
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb":
case "unlimited": case "unli": {
    if (!isOwner && !isReseller) return m.reply(`Maaf fitur ini hanya untuk ${global.owner}`);
    if (!text) return m.reply("Contoh penggunaan: .1gb username,628xxx");

    // Parse input
    const [username, nomorInput] = text.split(",").map(item => item.trim());
    if (!username) return m.reply("Username harus diisi!");
    
    const nomor = nomorInput 
        ? nomorInput.replace(/[^0-9]/g, "") + "@s.whatsapp.net" 
        : m.isGroup ? m.sender : m.chat;

    // Validate WhatsApp number
    const onWa = await VarShade.onWhatsApp(nomor.split("@")[0]);
    if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");

    // Set resources based on command
    const resourceMap = {
        "1gb": { ram: 1024, disk: 1024, cpu: 30 },
        "2gb": { ram: 2048, disk: 2048, cpu: 50 },
        "3gb": { ram: 3072, disk: 3072, cpu: 70 },
        "4gb": { ram: 4096, disk: 4096, cpu: 90 },
        "5gb": { ram: 5120, disk: 5120, cpu: 110 },
        "6gb": { ram: 6144, disk: 6144, cpu: 125 },
        "7gb": { ram: 7168, disk: 7168, cpu: 150 },
        "8gb": { ram: 8192, disk: 8192, cpu: 170 },
        "9gb": { ram: 9216, disk: 9216, cpu: 180 },
        "10gb": { ram: 10240, disk: 10240, cpu: 200 },
        "unli": { ram: 0, disk: 0, cpu: 0 }
    };
    const { ram, disk: disknya, cpu } = resourceMap[command] || resourceMap["1gb"];

    // Generate credentials
    const email = `${username}@varshade.xyz`;
    const password = username + crypto.randomBytes(3).toString('hex');
    const name = capital(username) + " xyz";

    // Calculate dates
    const now = new Date();
    const expiredDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const garansiDate = new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000);
    
    const formatDate = (date) => tanggal(date.getTime());
    const createdString = formatDate(now);
    const expiredString = formatDate(expiredDate);
    const garansiString = formatDate(garansiDate);

    await m.reply('⏳ Membuat akun panel...');
    let user, server;
    try {
        const userRes = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey
            },
            body: JSON.stringify({
                email: email,
                username: username,
                first_name: name,
                last_name: "Server",
                language: "en",
                password: password
            })
        });
        user = await userRes.json();
        if (user.errors) throw user.errors[0].detail;

        const eggRes = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey
            }
        });
        const eggData = await eggRes.json();
        const startup_cmd = eggData.attributes.startup || "npm start";
        const serverRes = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            },
            body: JSON.stringify({
                name: name,
                description: `Created: ${createdString} | Expired: ${expiredString}`,
                user: user.attributes.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start"
                },
                limits: {
                    memory: ram,
                    swap: 0,
                    disk: disknya,
                    io: 500,
                    cpu: cpu
                },
                feature_limits: {
                    databases: 5,
                    backups: 5,
                    allocations: 5
                },
                deploy: {
                    locations: [parseInt(loc)],
                    dedicated_ip: false,
                    port_range: [],
                }
            })
        });
        server = await serverRes.json();
        if (server.errors) throw server.errors[0].detail;
    } catch (e) {
        return m.reply(`❌ Gagal membuat panel: ${e.message || e}`);
    }
    const caption = `*📦 Detail Akun Panel Kamu*\n\n`
        + `🔹 *Username:* ${username}\n`
        + `🔹 *Password:* ${password}\n\n`
        + `📅 *Expired:* ${expiredString}\n`
        + `🛡️ *Garansi:* ${garansiString}\n\n`
        + `💾 *Spesifikasi:*\n`
        + `- RAM: ${ram ? ram/1024 + 'GB' : 'Unlimited'}\n`
        + `- Disk: ${disknya ? disknya/1024 + 'GB' : 'Unlimited'}\n`
        + `- CPU: ${cpu ? cpu + '%' : 'Unlimited'}\n\n`
        + `${global.domain}`;
    const buttons = [
        {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
                display_text: "ᴄᴏᴘʏ ᴜsᴇʀɴᴀᴍᴇ",
                copy_code: username
            })
        },
        {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
                display_text: "ᴄᴏᴘʏ ᴘᴀssᴡᴏʀᴅ",
                copy_code: password
            })
        },
       {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
        display_text: "ʟᴏɢɪɴ ᴘᴀɴᴇʟ",
        url: global.domain,
        merchant_url: global.domain
       })
      }
    ];
    const media = await prepareWAMessageMedia(
        { image: { url: 'https://files.catbox.moe/si1g2b.jpg' } },
        { upload: VarShade.waUploadToServer }
    );
    const msg = {
        interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: true,
                ...media
            }),
            body: proto.Message.InteractiveMessage.Body.create({ 
                text: caption 
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({ 
                text: "Simpan baik-baik data akun ini!" 
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
                buttons 
            })
        })
    };

    await VarShade.relayMessage(nomor, msg, { messageId: m.key.id });

    await m.reply(`✅ Akun panel berhasil dibuat untuk @${nomor.split("@")[0]}\nData telah dikirim ke nomor tersebut.`)
}
break
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listpanel": case "listp": case "listserver": {
if (!isOwner && !isReseller) return m.reply(`Maaf fitur ini hanya untuk *reseller panel*!\nBeli akses *reseller panel* langsung chat ${global.owner}`)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak ada server panel!")
let messageText = "\n *乂 List Server Panel Pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n 📡 *${s.id} >> [ ${s.name} ]*
 *• Ram :* ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}
 *• CPU :* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}
 *• Disk :* ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}
 *• Created :* ${s.created_at.split("T")[0]}\n`
}
await VarShade.sendMessage(m.chat, {text: messageText}, {quoted: qchannel})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delpanel": {
if (!isOwner && !isReseller) return m.reply(`Maaf fitur ini hanya untuk *reseller panel*!\nBeli akses *reseller panel* langsung chat ${global.owner}`)
if (!text) return example("idnya")
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Gagal menghapus server!\nID server tidak ditemukan")
await m.reply(`Sukses menghapus server panel *${capital(nameSrv)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "adp": {
    if (!isOwner) return m.reply(msg.owner);
    if (!text) return example("username,628XXX");

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek;
        if (!users || !nom) return example("username,628XXX");
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat;
    }

    let onWa = await VarShade.onWhatsApp(nomor.split("@")[0]);
    if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!");

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = capital(args[0]);
    let password = username + crypto.randomBytes(2).toString('hex');

    // Hitung tanggal expired & garansi
    let now = new Date();
    let expiredDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    let garansiDate = new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000);
    let createdString = tanggal(now.getTime());
    let expiredString = tanggal(expiredDate.getTime());
    let garansiString = tanggal(garansiDate.getTime());

    let f = await fetch(domain + "/api/application/users", {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey
        },
        body: JSON.stringify({
            email: email,
            username: username,
            first_name: name,
            last_name: "Admin",
            root_admin: true,
            language: "en",
            password: password
        })
    });

    let data = await f.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
    let user = data.attributes;

    let orang = nomor;
    if (m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah dikirim ke ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`);
    }
    if (nomor !== m.sender && !m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah dikirim ke ${nomor.split("@")[0]}`);
    }

    let teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ Dibuat :* ${createdString}
*📆 Expired :* ${expiredString}

*🌐* ${global.domain}

📌 Syarat & Ketentuan:
• ⌛️ Masa aktif akun: 30 hari
• ❌ Dilarang open reseller
• ❌ Dilarang create admin
• ❌ Jangan asal hapus server!
• ✅ Simpan data ini baik-baik (data hanya dikirim 1 kali)
• ⚠️ Ketahuan rusuh = akun dihapus tanpa refund
• ⚠️ Ketahuan maling = akun dihapus tanpa refund
• ⚠️ Ketahuan akses/buka server orang = akun dihapus tanpa refund
`;

    await VarShade.sendMessage(orang, { text: teks });
}
break;
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listadmin": {
if (!isOwner) return m.reply(msg.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List Admin Panel Pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n 📡 *${i.attributes.id} >> [ ${i.attributes.first_name} ]*
 *• Nama :* ${i.attributes.first_name}
 *• Created :* ${i.attributes.created_at.split("T")[0]}\n`
})
await VarShade.sendMessage(m.chat, {text: teks}, {quoted: qchannel})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deladmin": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("idnya")
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Gagal menghapus akun!\nID user tidak ditemukan")
await m.reply(`Sukses menghapus akun admin panel *${capital(getid)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

default:
if ((m.text).startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return VarShade.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return VarShade.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return VarShade.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return VarShade.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
VarShade.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
VarShade.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
VarShade.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(
    chalk.greenBright('🔄 Deteksi perubahan!'),
    chalk.white('->'),
    chalk.cyanBright.bold(__filename)
  );
  console.log(chalk.yellowBright('🚀 Memuat ulang file...'));
  delete require.cache[file];
  require(file);
});